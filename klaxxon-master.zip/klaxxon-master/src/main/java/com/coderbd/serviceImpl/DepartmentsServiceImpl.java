package com.coderbd.serviceImpl;

import com.coderbd.entity.Departments;
import com.coderbd.repo.DepartmentsRepo;
import com.coderbd.service.DepartmentsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DepartmentsServiceImpl implements DepartmentsService {
    @Autowired
    private DepartmentsRepo repo;
    @Override
    public Departments findByDepartmentName(String departmentName) {
        return repo.findByDepartmentName(departmentName);
    }
}
