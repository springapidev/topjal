package com.coderbd.service;

import com.coderbd.entity.Departments;

public interface DepartmentsService {
    Departments findByDepartmentName(String departmentName);
}
