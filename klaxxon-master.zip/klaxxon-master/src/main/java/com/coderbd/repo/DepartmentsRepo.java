package com.coderbd.repo;

import com.coderbd.entity.Departments;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentsRepo extends JpaRepository<Departments, Long> {
    Departments findByDepartmentName(String departmentName);
}
