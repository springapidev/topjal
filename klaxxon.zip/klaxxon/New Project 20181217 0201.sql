-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.6.35-log


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema klax
--

CREATE DATABASE IF NOT EXISTS klax;
USE klax;

--
-- Definition of table `arms_types`
--

DROP TABLE IF EXISTS `arms_types`;
CREATE TABLE `arms_types` (
  `armstypeid` int(11) NOT NULL AUTO_INCREMENT,
  `armstype` varchar(255) NOT NULL,
  PRIMARY KEY (`armstypeid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `arms_types`
--

/*!40000 ALTER TABLE `arms_types` DISABLE KEYS */;
INSERT INTO `arms_types` (`armstypeid`,`armstype`) VALUES 
 (1,'Avoid'),
 (2,'Retain'),
 (3,'Modify'),
 (4,'Share');
/*!40000 ALTER TABLE `arms_types` ENABLE KEYS */;


--
-- Definition of table `category_types`
--

DROP TABLE IF EXISTS `category_types`;
CREATE TABLE `category_types` (
  `category_typeid` int(11) NOT NULL AUTO_INCREMENT,
  `category_type` varchar(255) NOT NULL,
  PRIMARY KEY (`category_typeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category_types`
--

/*!40000 ALTER TABLE `category_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_types` ENABLE KEYS */;


--
-- Definition of table `companies`
--

DROP TABLE IF EXISTS `companies`;
CREATE TABLE `companies` (
  `companyid` bigint(20) NOT NULL AUTO_INCREMENT,
  `company_address` varchar(255) DEFAULT NULL,
  `company_city` varchar(255) DEFAULT NULL,
  `company_email` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_phone` varchar(255) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`companyid`),
  UNIQUE KEY `UKy9yro0sifsgyp79ls73lgvnj` (`company_name`,`user_id`),
  KEY `FKcxq6xyjap4fhi61ooew78lo5g` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `companies`
--

/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` (`companyid`,`company_address`,`company_city`,`company_email`,`company_name`,`company_phone`,`created_date`,`user_id`) VALUES 
 (1,'110 South City','Adelaide','abc@klaxxon.com','ABC co.','+8801686239145','2018-12-14 12:10:31',2),
 (2,'110 South Adelaide','New York','topjal@klaxxon.com','Topjal LLC','+8801686239146','2018-12-14 13:15:24',2);
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;


--
-- Definition of table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
CREATE TABLE `contacts` (
  `contactid` int(11) NOT NULL AUTO_INCREMENT,
  `contact_email` varchar(255) DEFAULT NULL,
  `contact_name` varchar(255) DEFAULT NULL,
  `contact_phone` int(11) DEFAULT NULL,
  `departmentid` bigint(20) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`contactid`),
  KEY `FK6gfwyru2ct3dx9gkxdi9s5n9w` (`departmentid`),
  KEY `FKf9pc3faerry2wp3xnahv2b0rg` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contacts`
--

/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` (`contactid`,`contact_email`,`contact_name`,`contact_phone`,`departmentid`,`created_date`,`user_id`) VALUES 
 (1,'scott@gmail.com','Scott Tunn',123456789,1,'2018-12-16 17:56:20',2);
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;


--
-- Definition of table `csf_types`
--

DROP TABLE IF EXISTS `csf_types`;
CREATE TABLE `csf_types` (
  `csftypeid` bigint(20) NOT NULL AUTO_INCREMENT,
  `csftype` varchar(255) NOT NULL,
  `process_typeid` bigint(20) NOT NULL,
  PRIMARY KEY (`csftypeid`),
  KEY `FKe6bvt3e92q2g6wlim3qk28ukb` (`process_typeid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `csf_types`
--

/*!40000 ALTER TABLE `csf_types` DISABLE KEYS */;
INSERT INTO `csf_types` (`csftypeid`,`csftype`,`process_typeid`) VALUES 
 (1,'Skills and Knowledge',5),
 (2,'Training',5),
 (3,'Incident Management',4),
 (4,'Problem Management',2),
 (5,'Change Management',2),
 (6,'Asset/Configuration Management',4),
 (7,'Release & Deployment Management',4),
 (8,'Access Management',4);
/*!40000 ALTER TABLE `csf_types` ENABLE KEYS */;


--
-- Definition of table `csfentry`
--

DROP TABLE IF EXISTS `csfentry`;
CREATE TABLE `csfentry` (
  `csfentryid` int(11) NOT NULL AUTO_INCREMENT,
  `csftypeid` bigint(20) NOT NULL,
  `impact_typeid` bigint(20) NOT NULL,
  `life_cycleid` int(11) NOT NULL,
  `process_typeid` bigint(20) NOT NULL,
  `risk_impact_typeid` bigint(20) NOT NULL,
  `service_typeid` int(11) NOT NULL,
  `vbfentryid` bigint(20) NOT NULL,
  PRIMARY KEY (`csfentryid`),
  KEY `FK15qvp4nomn5gxux1tk56qkgly` (`csftypeid`),
  KEY `FK5rd4o0axjigro74l35ob2yafb` (`impact_typeid`),
  KEY `FKcoci4id3dd8728ctv4i86eamc` (`life_cycleid`),
  KEY `FK5cxm7xxgj0ftowbybrbvi6pwc` (`process_typeid`),
  KEY `FK5wibe2c8bta3g3xmhxxup45d1` (`risk_impact_typeid`),
  KEY `FKbinp90b5lrftclsmxsb1p999v` (`service_typeid`),
  KEY `FKqpgxgi7xfhy1f9hn0xxktcbj1` (`vbfentryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `csfentry`
--

/*!40000 ALTER TABLE `csfentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `csfentry` ENABLE KEYS */;


--
-- Definition of table `departmentcontacts`
--

DROP TABLE IF EXISTS `departmentcontacts`;
CREATE TABLE `departmentcontacts` (
  `contactid` int(11) NOT NULL,
  `departmentid` bigint(20) NOT NULL,
  KEY `FKllsv6fpboto0jausa4e0j1nxx` (`departmentid`),
  KEY `FK4cnrtdrdqmnc6lu3lu3fl1ar3` (`contactid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `departmentcontacts`
--

/*!40000 ALTER TABLE `departmentcontacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `departmentcontacts` ENABLE KEYS */;


--
-- Definition of table `departments`
--

DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `departmentid` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `department_name` varchar(255) NOT NULL,
  `company_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`departmentid`),
  UNIQUE KEY `UK1pm2pm1t2bf3igqnf4o14mo5k` (`department_name`,`company_id`,`user_id`),
  KEY `FKoq64wrpwbvd4lq19c3qyxykl0` (`company_id`),
  KEY `FKr05dj6b0f9e7x97wp2rv5b1jr` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `departments`
--

/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` (`departmentid`,`created_date`,`department_name`,`company_id`,`user_id`) VALUES 
 (1,'2018-12-14 12:10:39','IT',1,2),
 (2,'2018-12-14 13:15:34','IT',2,2);
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;


--
-- Definition of table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `hibernate_sequence`
--

/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
INSERT INTO `hibernate_sequence` (`next_val`) VALUES 
 (3),
 (3),
 (3);
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;


--
-- Definition of table `impact_types`
--

DROP TABLE IF EXISTS `impact_types`;
CREATE TABLE `impact_types` (
  `impact_typeid` bigint(20) NOT NULL AUTO_INCREMENT,
  `impact` varchar(255) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`impact_typeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `impact_types`
--

/*!40000 ALTER TABLE `impact_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `impact_types` ENABLE KEYS */;


--
-- Definition of table `klaxxon_old`
--

DROP TABLE IF EXISTS `klaxxon_old`;
CREATE TABLE `klaxxon_old` (
  `threats_entryid` int(11) NOT NULL AUTO_INCREMENT,
  `csfentryid` int(11) NOT NULL,
  `rate_occurenceid` int(11) NOT NULL,
  `threat_iikelihood_typeid` bigint(20) NOT NULL,
  `threat_impact_typeid` bigint(20) NOT NULL,
  `threat_typeid` int(11) NOT NULL,
  PRIMARY KEY (`threats_entryid`),
  UNIQUE KEY `UKfyi9tlnkjqd6qux5812k08lxo` (`csfentryid`),
  KEY `FK5po7c7r0cw469ogmswfy672o8` (`rate_occurenceid`),
  KEY `FKl2fmuon6ksnh681lvawkou5k` (`threat_iikelihood_typeid`),
  KEY `FKrf42ym4p8qpmiley4nc4a5y36` (`threat_impact_typeid`),
  KEY `FKfny48olbn5y55es941apwov08` (`threat_typeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `klaxxon_old`
--

/*!40000 ALTER TABLE `klaxxon_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `klaxxon_old` ENABLE KEYS */;


--
-- Definition of table `kpis`
--

DROP TABLE IF EXISTS `kpis`;
CREATE TABLE `kpis` (
  `kpiid` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `csfentryid` int(11) NOT NULL,
  `category_typeid` int(11) NOT NULL,
  `contactid` int(11) NOT NULL,
  `departmentid` bigint(20) NOT NULL,
  PRIMARY KEY (`kpiid`),
  KEY `FKrb6qiot9i0vw74nn6jf1ic27e` (`csfentryid`),
  KEY `FKow77q3sra1xhi43n7wtvnjm3r` (`category_typeid`),
  KEY `FKqvsobcvig77swmi5pp7sldlxs` (`contactid`),
  KEY `FK1qv6w89ewagm60y4apfv88c4c` (`departmentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kpis`
--

/*!40000 ALTER TABLE `kpis` DISABLE KEYS */;
/*!40000 ALTER TABLE `kpis` ENABLE KEYS */;


--
-- Definition of table `life_cycles`
--

DROP TABLE IF EXISTS `life_cycles`;
CREATE TABLE `life_cycles` (
  `life_cycleid` int(11) NOT NULL AUTO_INCREMENT,
  `life_cycle` varchar(255) NOT NULL,
  PRIMARY KEY (`life_cycleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `life_cycles`
--

/*!40000 ALTER TABLE `life_cycles` DISABLE KEYS */;
/*!40000 ALTER TABLE `life_cycles` ENABLE KEYS */;


--
-- Definition of table `privilize`
--

DROP TABLE IF EXISTS `privilize`;
CREATE TABLE `privilize` (
  `id` bigint(20) NOT NULL,
  `privilize_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_m07onguse6k82umgeana3uska` (`privilize_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `privilize`
--

/*!40000 ALTER TABLE `privilize` DISABLE KEYS */;
/*!40000 ALTER TABLE `privilize` ENABLE KEYS */;


--
-- Definition of table `process_types`
--

DROP TABLE IF EXISTS `process_types`;
CREATE TABLE `process_types` (
  `process_typeid` bigint(20) NOT NULL AUTO_INCREMENT,
  `process_type` varchar(255) NOT NULL,
  PRIMARY KEY (`process_typeid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `process_types`
--

/*!40000 ALTER TABLE `process_types` DISABLE KEYS */;
INSERT INTO `process_types` (`process_typeid`,`process_type`) VALUES 
 (2,'Partner'),
 (3,'Product'),
 (4,'Process'),
 (5,'People');
/*!40000 ALTER TABLE `process_types` ENABLE KEYS */;


--
-- Definition of table `processtypestakeholdertypes`
--

DROP TABLE IF EXISTS `processtypestakeholdertypes`;
CREATE TABLE `processtypestakeholdertypes` (
  `process_typeid` bigint(20) NOT NULL,
  `stakeholder_typeid` bigint(20) NOT NULL,
  KEY `FKs5legpvmmywfrecuok1tbruay` (`stakeholder_typeid`),
  KEY `FKrmly5mo4b0kogu8dwk1nwjhhi` (`process_typeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `processtypestakeholdertypes`
--

/*!40000 ALTER TABLE `processtypestakeholdertypes` DISABLE KEYS */;
INSERT INTO `processtypestakeholdertypes` (`process_typeid`,`stakeholder_typeid`) VALUES 
 (1,1),
 (1,3),
 (1,4),
 (2,2),
 (2,3),
 (3,4),
 (4,2),
 (5,3),
 (5,4),
 (5,5),
 (5,6);
/*!40000 ALTER TABLE `processtypestakeholdertypes` ENABLE KEYS */;


--
-- Definition of table `rate_occurences`
--

DROP TABLE IF EXISTS `rate_occurences`;
CREATE TABLE `rate_occurences` (
  `rate_occurenceid` int(11) NOT NULL AUTO_INCREMENT,
  `occurence` varchar(255) NOT NULL,
  `rate` double DEFAULT NULL,
  PRIMARY KEY (`rate_occurenceid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rate_occurences`
--

/*!40000 ALTER TABLE `rate_occurences` DISABLE KEYS */;
/*!40000 ALTER TABLE `rate_occurences` ENABLE KEYS */;


--
-- Definition of table `review_periods`
--

DROP TABLE IF EXISTS `review_periods`;
CREATE TABLE `review_periods` (
  `review_periodid` int(11) NOT NULL AUTO_INCREMENT,
  `review_period` varchar(255) NOT NULL,
  PRIMARY KEY (`review_periodid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `review_periods`
--

/*!40000 ALTER TABLE `review_periods` DISABLE KEYS */;
INSERT INTO `review_periods` (`review_periodid`,`review_period`) VALUES 
 (1,'Daily'),
 (2,'Weekly'),
 (3,'Monthly'),
 (4,'Yearly');
/*!40000 ALTER TABLE `review_periods` ENABLE KEYS */;


--
-- Definition of table `risk_entry`
--

DROP TABLE IF EXISTS `risk_entry`;
CREATE TABLE `risk_entry` (
  `risk_entryid` int(11) NOT NULL AUTO_INCREMENT,
  `attach_risk_treatment_plan` varchar(255) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `implementation_cost` double DEFAULT NULL,
  `review_date` date DEFAULT NULL,
  `risk_aversion` int(11) NOT NULL,
  `risk_name` varchar(255) DEFAULT NULL,
  `risk_treatment` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `armstypeid` int(11) DEFAULT NULL,
  `csfentryid` int(11) NOT NULL,
  `contactid` int(11) NOT NULL,
  `review_periodid` int(11) DEFAULT NULL,
  PRIMARY KEY (`risk_entryid`),
  UNIQUE KEY `UKm620erdkq0c3tl17bqmx5gljk` (`csfentryid`),
  KEY `FKjhvgs5pfumyoqjncoem2lwdo8` (`armstypeid`),
  KEY `FKcjvnhsavwli1658mhgcr2rj22` (`contactid`),
  KEY `FKibsyqp59um5usjaqtdt7d9j9l` (`review_periodid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `risk_entry`
--

/*!40000 ALTER TABLE `risk_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `risk_entry` ENABLE KEYS */;


--
-- Definition of table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL,
  `rolename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_nctmxadhieiw7aduxjy4dfglt` (`rolename`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `role`
--

/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`id`,`rolename`) VALUES 
 (1,'ADMIN');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;


--
-- Definition of table `role_privilize`
--

DROP TABLE IF EXISTS `role_privilize`;
CREATE TABLE `role_privilize` (
  `role_id` bigint(20) NOT NULL,
  `privilize_id` bigint(20) NOT NULL,
  PRIMARY KEY (`role_id`,`privilize_id`),
  KEY `FK6opfi7gw55kkaqk1ap36soedn` (`privilize_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `role_privilize`
--

/*!40000 ALTER TABLE `role_privilize` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_privilize` ENABLE KEYS */;


--
-- Definition of table `service_types`
--

DROP TABLE IF EXISTS `service_types`;
CREATE TABLE `service_types` (
  `service_typeid` int(11) NOT NULL AUTO_INCREMENT,
  `service_type` varchar(255) NOT NULL,
  `weigh` int(11) NOT NULL,
  PRIMARY KEY (`service_typeid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `service_types`
--

/*!40000 ALTER TABLE `service_types` DISABLE KEYS */;
INSERT INTO `service_types` (`service_typeid`,`service_type`,`weigh`) VALUES 
 (1,'Core Service',8),
 (2,'Enabling Service',6),
 (3,'Enhancing Service',3);
/*!40000 ALTER TABLE `service_types` ENABLE KEYS */;


--
-- Definition of table `stake_holder_entry`
--

DROP TABLE IF EXISTS `stake_holder_entry`;
CREATE TABLE `stake_holder_entry` (
  `stakeholder_entryid` int(11) NOT NULL AUTO_INCREMENT,
  `csfentryid` int(11) NOT NULL,
  `risk_impact_typeid` bigint(20) NOT NULL,
  `stakeholder_typeid` bigint(20) NOT NULL,
  `value_and_importance_impact_typeid` bigint(20) NOT NULL,
  PRIMARY KEY (`stakeholder_entryid`),
  UNIQUE KEY `UKo4perx8afuurdbfmlbaioclrx` (`csfentryid`),
  KEY `FKp7fjkg2pekbdt6mqv74rmmks9` (`risk_impact_typeid`),
  KEY `FKc8ljmuh78r0u4q8tpyy3eci9h` (`stakeholder_typeid`),
  KEY `FK7jbdyskr1vtuhitwjwxpotmai` (`value_and_importance_impact_typeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stake_holder_entry`
--

/*!40000 ALTER TABLE `stake_holder_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `stake_holder_entry` ENABLE KEYS */;


--
-- Definition of table `stake_holder_types`
--

DROP TABLE IF EXISTS `stake_holder_types`;
CREATE TABLE `stake_holder_types` (
  `stakeholder_typeid` bigint(20) NOT NULL AUTO_INCREMENT,
  `stakeholder_type` varchar(255) NOT NULL,
  PRIMARY KEY (`stakeholder_typeid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stake_holder_types`
--

/*!40000 ALTER TABLE `stake_holder_types` DISABLE KEYS */;
INSERT INTO `stake_holder_types` (`stakeholder_typeid`,`stakeholder_type`) VALUES 
 (1,'Customers & Clients'),
 (2,'Owners'),
 (3,'Commodity Suppliers'),
 (4,'Employees'),
 (5,'Legal & Regulatory Authorities'),
 (6,'Competitors & Industry Bodies'),
 (7,'Operational Suppliers');
/*!40000 ALTER TABLE `stake_holder_types` ENABLE KEYS */;


--
-- Definition of table `threat_impact_types`
--

DROP TABLE IF EXISTS `threat_impact_types`;
CREATE TABLE `threat_impact_types` (
  `impact_typeid` int(11) NOT NULL AUTO_INCREMENT,
  `impact` varchar(255) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`impact_typeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `threat_impact_types`
--

/*!40000 ALTER TABLE `threat_impact_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `threat_impact_types` ENABLE KEYS */;


--
-- Definition of table `threat_types`
--

DROP TABLE IF EXISTS `threat_types`;
CREATE TABLE `threat_types` (
  `threat_typeid` int(11) NOT NULL AUTO_INCREMENT,
  `threat_type` varchar(255) NOT NULL,
  `threat_type_duration` varchar(255) DEFAULT NULL,
  `vulnerability_reference` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`threat_typeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `threat_types`
--

/*!40000 ALTER TABLE `threat_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `threat_types` ENABLE KEYS */;


--
-- Definition of table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `activation_key` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `is_ctivated` bit(1) DEFAULT NULL,
  `joining_date` datetime DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `reset_pass_key` varchar(100) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe` (`email`),
  UNIQUE KEY `UK_cnjwxx5favk5ycqajjt17fwy1` (`mobile`),
  UNIQUE KEY `UK_sb8bbouer5wak8vyiiy4pf2bx` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`,`activation_key`,`email`,`first_name`,`is_ctivated`,`joining_date`,`last_name`,`mobile`,`password`,`reset_pass_key`,`username`) VALUES 
 (2,NULL,'rajaul.cse@gmail.com','Rajaul',0x01,'2018-12-14 12:09:59','Islam','01686239146','$2a$10$GBYDyS0hanGo20.npXFl5e.tSpkD.rGzyLaUxLBHQcvC4pMXPM8f.',NULL,'admin');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Definition of table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `user_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `FKa68196081fvovjhkek5m97n3y` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_role`
--

/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` (`user_id`,`role_id`) VALUES 
 (2,1);
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;


--
-- Definition of table `vbf_business_impact_types`
--

DROP TABLE IF EXISTS `vbf_business_impact_types`;
CREATE TABLE `vbf_business_impact_types` (
  `impact_typeid` bigint(20) NOT NULL AUTO_INCREMENT,
  `impact` varchar(255) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`impact_typeid`),
  UNIQUE KEY `UK_o57v7l2mwqym92usgue3unlwq` (`impact`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vbf_business_impact_types`
--

/*!40000 ALTER TABLE `vbf_business_impact_types` DISABLE KEYS */;
INSERT INTO `vbf_business_impact_types` (`impact_typeid`,`impact`,`weight`) VALUES 
 (1,'low',1),
 (2,'Medium',2),
 (3,'High',3);
/*!40000 ALTER TABLE `vbf_business_impact_types` ENABLE KEYS */;


--
-- Definition of table `vbf_entry`
--

DROP TABLE IF EXISTS `vbf_entry`;
CREATE TABLE `vbf_entry` (
  `vbfentryid` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `misson` varchar(500) DEFAULT NULL,
  `revenue` double NOT NULL,
  `vision` varchar(500) DEFAULT NULL,
  `impact_type_id` bigint(20) NOT NULL,
  `department_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `vbf_type_id` bigint(20) NOT NULL,
  `vbf_likelihood_type_id` bigint(20) NOT NULL,
  PRIMARY KEY (`vbfentryid`),
  KEY `FKoqwxii0nowxb7d1r78195rvv0` (`impact_type_id`),
  KEY `FKam75itcqwtgsamo0cxigy2h60` (`department_id`),
  KEY `FKesntvft17lqc1rccleo63fgtu` (`user_id`),
  KEY `FKa3rhg52nnjm662flo7yiktcuf` (`vbf_type_id`),
  KEY `FK2awri3gt3g5oladwh40yg84a6` (`vbf_likelihood_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vbf_entry`
--

/*!40000 ALTER TABLE `vbf_entry` DISABLE KEYS */;
INSERT INTO `vbf_entry` (`vbfentryid`,`created_date`,`misson`,`revenue`,`vision`,`impact_type_id`,`department_id`,`user_id`,`vbf_type_id`,`vbf_likelihood_type_id`) VALUES 
 (1,'2018-12-14 12:19:15','My Mission',50000,'My Vission',1,1,2,1,1),
 (2,'2018-12-14 13:16:42','My Mission',550000,'My Vission',2,2,2,3,3);
/*!40000 ALTER TABLE `vbf_entry` ENABLE KEYS */;


--
-- Definition of table `vbf_likelihood_types`
--

DROP TABLE IF EXISTS `vbf_likelihood_types`;
CREATE TABLE `vbf_likelihood_types` (
  `impact_typeid` bigint(20) NOT NULL AUTO_INCREMENT,
  `impact` varchar(255) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`impact_typeid`),
  UNIQUE KEY `UK_id66ygbnwvc3soes5to478olg` (`impact`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vbf_likelihood_types`
--

/*!40000 ALTER TABLE `vbf_likelihood_types` DISABLE KEYS */;
INSERT INTO `vbf_likelihood_types` (`impact_typeid`,`impact`,`weight`) VALUES 
 (1,'low',1),
 (2,'Medium',2),
 (3,'High',3);
/*!40000 ALTER TABLE `vbf_likelihood_types` ENABLE KEYS */;


--
-- Definition of table `vbf_types`
--

DROP TABLE IF EXISTS `vbf_types`;
CREATE TABLE `vbf_types` (
  `vbftypeid` bigint(20) NOT NULL AUTO_INCREMENT,
  `vbftype` varchar(255) NOT NULL,
  PRIMARY KEY (`vbftypeid`),
  UNIQUE KEY `UK_l6nrjs0avpyvt5tpipydacprr` (`vbftype`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vbf_types`
--

/*!40000 ALTER TABLE `vbf_types` DISABLE KEYS */;
INSERT INTO `vbf_types` (`vbftypeid`,`vbftype`) VALUES 
 (1,'Email'),
 (2,'Power'),
 (3,'Online Payment Gateway'),
 (4,'Database Collaboration Engine'),
 (5,'Telephone'),
 (6,'Service Desk'),
 (7,'Payroll'),
 (8,'Computer Hardware'),
 (9,'HR (Human Resource Development'),
 (10,'Examination sales'),
 (11,'Continuous integration'),
 (12,'Elearning Portal (ITIL Training)'),
 (13,'Elearning Portal (ITIL Training'),
 (14,'Wire harness provision'),
 (15,'Nuclear centrifuge');
/*!40000 ALTER TABLE `vbf_types` ENABLE KEYS */;


--
-- Definition of table `vulnerability_entry`
--

DROP TABLE IF EXISTS `vulnerability_entry`;
CREATE TABLE `vulnerability_entry` (
  `vulnerability_entryid` int(11) NOT NULL AUTO_INCREMENT,
  `current_level_cover` float DEFAULT NULL,
  `csfentryid` int(11) NOT NULL,
  `impact_typeid` bigint(20) NOT NULL,
  `vulnerability_typeid` int(11) NOT NULL,
  PRIMARY KEY (`vulnerability_entryid`),
  UNIQUE KEY `UKh9o0lnwmepe2cueqk3isrh3x0` (`csfentryid`),
  KEY `FKgas4ukypbltlm0l3rlgqo2g3b` (`impact_typeid`),
  KEY `FKmegdp1mqw9qldkxbde399n9hq` (`vulnerability_typeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vulnerability_entry`
--

/*!40000 ALTER TABLE `vulnerability_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `vulnerability_entry` ENABLE KEYS */;


--
-- Definition of table `vulnerability_types`
--

DROP TABLE IF EXISTS `vulnerability_types`;
CREATE TABLE `vulnerability_types` (
  `vulnerability_typeid` int(11) NOT NULL AUTO_INCREMENT,
  `vulnerability_type` varchar(255) NOT NULL,
  `life_cycleid` int(11) NOT NULL,
  PRIMARY KEY (`vulnerability_typeid`),
  KEY `FKpnagj598ud0qiwj39asrv6vvv` (`life_cycleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vulnerability_types`
--

/*!40000 ALTER TABLE `vulnerability_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `vulnerability_types` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
