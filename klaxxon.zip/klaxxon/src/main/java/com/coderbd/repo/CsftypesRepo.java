package com.coderbd.repo;

import com.coderbd.entity.Csftypes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CsftypesRepo extends JpaRepository<Csftypes, Long> {
    Csftypes findByCSFType(String cSFType);
}
