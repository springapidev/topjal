package com.coderbd.repo;

import com.coderbd.entity.Categorytypes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategorytypesRepo extends JpaRepository<Categorytypes, Long> {
    Categorytypes findByCategoryType(String categoriestYpe);
}
