package com.coderbd.repo;

import com.coderbd.entity.Reviewperiods;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReviewperiodsRepo extends JpaRepository<Reviewperiods,Long> {
    Reviewperiods findByReviewPeriod(String reviewPeriod);
}
