package com.coderbd.repo;

import com.coderbd.entity.Riskentry;
import com.coderbd.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RiskentryRepo extends JpaRepository<Riskentry, Long> {
    Riskentry findByRiskName(String riskName);
    List<Riskentry> findAllByUser(User user);
}
