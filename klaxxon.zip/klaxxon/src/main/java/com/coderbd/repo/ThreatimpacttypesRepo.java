package com.coderbd.repo;

import com.coderbd.entity.Threatimpacttypes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ThreatimpacttypesRepo extends JpaRepository<Threatimpacttypes, Long> {
    Threatimpacttypes findByImpact(String impact);
}
