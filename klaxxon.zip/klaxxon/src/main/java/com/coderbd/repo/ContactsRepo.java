package com.coderbd.repo;

import com.coderbd.entity.Contacts;
import com.coderbd.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ContactsRepo extends JpaRepository<Contacts, Long> {
    Contacts findByContactEmail(String contactEmail);
    Contacts findAllByUser(User user);
}
