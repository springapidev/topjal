package com.coderbd.repo;

import com.coderbd.entity.Armstypes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ArmstypesRepo extends JpaRepository<Armstypes, Long> {
    Armstypes findByARMSType(String aRMSType);
}
