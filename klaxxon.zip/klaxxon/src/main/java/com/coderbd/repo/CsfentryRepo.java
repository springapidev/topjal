package com.coderbd.repo;

import com.coderbd.entity.Csfentry;
import com.coderbd.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CsfentryRepo extends JpaRepository<Csfentry, Long> {
    List<Csfentry> findAllByUser(User user);
}
