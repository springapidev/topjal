package com.coderbd.repo;

import com.coderbd.entity.Servicetypes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ServicetypesRepo extends JpaRepository<Servicetypes, Long> {
    Servicetypes findByServiceType(String serviceType);
}
