package com.coderbd.service;

import com.coderbd.entity.Vbftypes;

public interface VbftypesService {
    Vbftypes findByVBFType(String vbfType);
}
