/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.coderbd.entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Rajail Islam
 */
@Entity
@Table(name = "vbf_entry")
public class Vbfentry implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(nullable = false)
    private Integer vBFEntryID;
    @Column(length = 500)
    private String vision;
    @Column(length = 500)
    private String misson;
    @Basic(optional = false)
    @Column(nullable = false)
    private double revenue;
    @JoinColumn(name = "DepartmentID", referencedColumnName = "DepartmentID", nullable = false)
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Departments departmentID;
    @JoinColumn(name = "BusinessImpactTypeID", referencedColumnName = "ImpactTypeID", nullable = false)
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Impacttypes businessImpactTypeID;
    @JoinColumn(name = "LikelihoodFallingImpactTypeID", referencedColumnName = "ImpactTypeID", nullable = false)
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Impacttypes likelihoodFallingImpactTypeID;
    @JoinColumn(name = "VBFTypeID", referencedColumnName = "VBFTypeID", nullable = false)
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Vbftypes vBFTypeID;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "vBFEntryID", fetch = FetchType.LAZY)
    private Collection<Csfentry> csfentryCollection;

    public Vbfentry() {
    }

    public Vbfentry(Integer vBFEntryID) {
        this.vBFEntryID = vBFEntryID;
    }

    public Vbfentry(Integer vBFEntryID, double revenue) {
        this.vBFEntryID = vBFEntryID;
        this.revenue = revenue;
    }

    public Integer getVBFEntryID() {
        return vBFEntryID;
    }

    public void setVBFEntryID(Integer vBFEntryID) {
        this.vBFEntryID = vBFEntryID;
    }

    public String getVision() {
        return vision;
    }

    public void setVision(String vision) {
        this.vision = vision;
    }

    public String getMisson() {
        return misson;
    }

    public void setMisson(String misson) {
        this.misson = misson;
    }

    public double getRevenue() {
        return revenue;
    }

    public void setRevenue(double revenue) {
        this.revenue = revenue;
    }

    public Departments getDepartmentID() {
        return departmentID;
    }

    public void setDepartmentID(Departments departmentID) {
        this.departmentID = departmentID;
    }

    public Impacttypes getBusinessImpactTypeID() {
        return businessImpactTypeID;
    }

    public void setBusinessImpactTypeID(Impacttypes businessImpactTypeID) {
        this.businessImpactTypeID = businessImpactTypeID;
    }

    public Impacttypes getLikelihoodFallingImpactTypeID() {
        return likelihoodFallingImpactTypeID;
    }

    public void setLikelihoodFallingImpactTypeID(Impacttypes likelihoodFallingImpactTypeID) {
        this.likelihoodFallingImpactTypeID = likelihoodFallingImpactTypeID;
    }

    public Vbftypes getVBFTypeID() {
        return vBFTypeID;
    }

    public void setVBFTypeID(Vbftypes vBFTypeID) {
        this.vBFTypeID = vBFTypeID;
    }

    public Collection<Csfentry> getCsfentryCollection() {
        return csfentryCollection;
    }

    public void setCsfentryCollection(Collection<Csfentry> csfentryCollection) {
        this.csfentryCollection = csfentryCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (vBFEntryID != null ? vBFEntryID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Vbfentry)) {
            return false;
        }
        Vbfentry other = (Vbfentry) object;
        if ((this.vBFEntryID == null && other.vBFEntryID != null) || (this.vBFEntryID != null && !this.vBFEntryID.equals(other.vBFEntryID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "klaxxon_reverse_eng.Vbfentry[ vBFEntryID=" + vBFEntryID + " ]";
    }

}
