package com.coderbd.controller;


import com.coderbd.entity.Processtypes;
import com.coderbd.entity.Riskentry;
import com.coderbd.repo.*;
import com.coderbd.service.UserService;
import com.coderbd.utils.LoggedInUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.Date;
import java.util.Optional;


@Controller
@RequestMapping("/riskentry/")
public class RiskEntryController {
    @Autowired
    private RiskentryRepo repo;
    @Autowired
    private ArmstypesRepo armstypesRepo;

    @Autowired
    private CsfentryRepo csfentryRepo;
    @Autowired
    private ContactsRepo contactsRepo;

    @Autowired
    private ReviewperiodsRepo reviewperiodsRepo;

    @Autowired
    private LoggedInUser loggedInUser;

    @Autowired
    private UserService userService;


    @RequestMapping(value = "create.do", method = RequestMethod.GET)
    public ModelAndView getView() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("obj", new Riskentry());
        modelAndView.addObject("list", repo.findAllByUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName())));
        modelAndView.addObject("armstypelist", armstypesRepo.findAll());
        modelAndView.addObject("csfentryList", csfentryRepo.findAll());
        modelAndView.addObject("contactsList", contactsRepo.findAllByUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName())));
        modelAndView.addObject("reviewperiodsList", reviewperiodsRepo.findAll());
        modelAndView.setViewName("risk-entry/create");
        return modelAndView;
    }

    @RequestMapping(value = "create.do", method = RequestMethod.POST)
    public String saveOrUpdate(@Valid @ModelAttribute("obj") Riskentry obj, BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()) {
            return "csf-entry";
        }   Riskentry riskentry =repo.findByRiskName(obj.getRiskName());
        if (riskentry != null) {
            model.addAttribute("riskentryNameError", "You already have inserted this");
            model.addAttribute("obj", new Processtypes());
            model.addAttribute("list", repo.findAllByUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName())));
            model.addAttribute("armstypelist", armstypesRepo.findAll());
            model.addAttribute("csfentryList", csfentryRepo.findAllByUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName())));
            model.addAttribute("contactsList", contactsRepo.findAllByUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName())));
            model.addAttribute("reviewperiodsList", reviewperiodsRepo.findAll());
            return "settings/risk-entry";
        } else {
            obj.setCreatedDate(new Date());
            obj.setUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName()));
            repo.save(obj);
            model.addAttribute("successMessage", "Insert Success");
            model.addAttribute("list", repo.findAllByUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName())));
            model.addAttribute("armstypelist", armstypesRepo.findAll());
            model.addAttribute("csfentryList", csfentryRepo.findAllByUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName())));
            model.addAttribute("contactsList", contactsRepo.findAllByUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName())));
            model.addAttribute("reviewperiodsList", reviewperiodsRepo.findAll());
            return "risk-entry/create";
        }
    }



    @RequestMapping(value = "edit/{id}", method = RequestMethod.GET)
    public String updateRole(@PathVariable Long id, Model model) {
        Optional<Riskentry> obj1 = repo.findById(id);
        model.addAttribute("obj", obj1);
        return "risk-entry";
    }

    @RequestMapping(value = "del/{id}", method = RequestMethod.GET)
    public String delRole(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("successMessage", "Delete Success");
        return "redirect:/riskentry/create";
    }
}


