package com.coderbd.controller;


import com.coderbd.entity.Csftypes;
import com.coderbd.repo.CsftypesRepo;
import com.coderbd.repo.ProcesstypesRepo;
import com.coderbd.service.UserService;
import com.coderbd.utils.LoggedInUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.Optional;


@Controller
@RequestMapping("/csftype/")
public class CsfTypesController {
    @Autowired
    private ProcesstypesRepo processtypesRepo;

    @Autowired
    private LoggedInUser loggedInUser;

    @Autowired
    private UserService userService;

@Autowired
private CsftypesRepo repo;

    @RequestMapping(value = "create.do", method = RequestMethod.GET)
    public ModelAndView getView() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("obj", new Csftypes());
        modelAndView.addObject("list", repo.findAll());
        modelAndView.addObject("processtypelist", processtypesRepo.findAll());
        modelAndView.setViewName("settings/csf-type");
        return modelAndView;
    }

    @RequestMapping(value = "create.do", method = RequestMethod.POST)
    public String saveOrUpdate(@Valid @ModelAttribute("obj") Csftypes obj, BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()) {
            return "settings/csf-type";
        } else {
            Csftypes csftypes =repo.findByCSFType(obj.getcSFType());
            if (csftypes != null) {
                model.addAttribute("csftypesError", "You already have inserted this");
                model.addAttribute("obj", new Csftypes());
                model.addAttribute("list", repo.findAll());
                model.addAttribute("processtypelist", processtypesRepo.findAll());
                return "settings/csf-type";
            } else {

                repo.save(obj);
                model.addAttribute("successMessage", "Insert Success");
                model.addAttribute("list", repo.findAll());
                model.addAttribute("processtypelist", processtypesRepo.findAll());
                return "settings/csf-type";
            }
        }

    }

    @RequestMapping(value = "edit/{id}", method = RequestMethod.GET)
    public String updateRole(@PathVariable Long id, Model model) {
        Optional<Csftypes> obj1 = repo.findById(id);
        model.addAttribute("obj", obj1);
        return "settings/csf-type";
    }

    @RequestMapping(value = "del/{id}", method = RequestMethod.GET)
    public String delRole(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("successMessage", "Delete Success");
        return "redirect:/csftype/create.do";
    }
}


