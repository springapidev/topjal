package com.coderbd.controller;

public class Test {
    public static String sayHello(){
        System.out.println("Called This Method::::");
        return "100";
    }
}
