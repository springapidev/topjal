package com.coderbd.controller;

import com.coderbd.entity.Categorytypes;
import com.coderbd.entity.Contacts;
import com.coderbd.entity.Departments;
import com.coderbd.entity.Kpis;
import com.coderbd.repo.*;
import com.coderbd.service.UserService;
import com.coderbd.utils.LoggedInUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.Optional;


@Controller
@RequestMapping("/kpis/")
public class KpisController {
    @Autowired
    private KpisRepo repo;
    @Autowired
    private LoggedInUser loggedInUser;
    @Autowired
    private UserService userService;
    @Autowired
    private CsfentryRepo csfentryRepo;
    @Autowired
    private CategorytypesRepo categorytypesRepo;
    @Autowired
    private ContactsRepo contactsRepo;
    @Autowired
    private CompaniesRepo companiesRepo;
    @Autowired
    private DepartmentsRepo departmentsRepo;


    @RequestMapping(value = "create.do", method = RequestMethod.GET)
    public ModelAndView getView() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("obj", new Kpis());
        modelAndView.addObject("list", repo.findAll());
        modelAndView.addObject("csfentryList", csfentryRepo.findAll());
        modelAndView.addObject("categorytypesList", categorytypesRepo.findAll());
        modelAndView.addObject("contactsList", contactsRepo.findAll());
        modelAndView.addObject("companiesList", companiesRepo.findAll());
        modelAndView.addObject("departmentsList", departmentsRepo.findAll());
        modelAndView.setViewName("kpis/create");
        return modelAndView;
    }

    @RequestMapping(value = "create.do", method = RequestMethod.POST)
    public String saveOrUpdate(@Valid @ModelAttribute("obj") Kpis obj, BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()) {
            return "kpis/create";
        } else {
            repo.save(obj);
            model.addAttribute("successMessage", "Insert Success");
            model.addAttribute("list", repo.findAll());
            model.addAttribute("csfentryList", csfentryRepo.findAll());
            model.addAttribute("categorytypesList", categorytypesRepo.findAll());
            model.addAttribute("contactsList", contactsRepo.findAll());
            model.addAttribute("companiesList", companiesRepo.findAll());
            model.addAttribute("departmentsList", departmentsRepo.findAll());
            return "kpis/create";
        }
    }


    @RequestMapping(value = "edit/{id}", method = RequestMethod.GET)
    public String updateRole(@PathVariable Long id, Model model) {
        Optional<Kpis> obj1 = repo.findById(id);
        model.addAttribute("obj", obj1);
        return "kpis/create";
    }

    @RequestMapping(value = "del/{id}", method = RequestMethod.GET)
    public String delRole(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("successMessage", "Delete Success");
        return "redirect:/kpis/create";
    }
}


