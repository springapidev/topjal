package com.coderbd.controller;


import com.coderbd.entity.Contacts;
import com.coderbd.repo.*;
import com.coderbd.service.DepartmentsService;
import com.coderbd.service.UserService;
import com.coderbd.utils.LoggedInUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Date;
import java.util.Optional;


@Controller
@RequestMapping("/contact/")
public class ContactController {
    @Autowired
    private ContactsRepo repo;

    @Autowired
    private LoggedInUser loggedInUser;

    @Autowired
    private UserService userService;

    @Autowired
    private CompaniesRepo companiesRepo;

    @Autowired
    private DepartmentsService departmentsService;


    @RequestMapping(value = "create.do", method = RequestMethod.GET)
    public ModelAndView getView(HttpServletRequest request) {//@RequestParam("companyID") Long comID, @RequestParam("depId") Long departmentId
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("obj", new Contacts());
        modelAndView.addObject("list", repo.findAllByUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName())));
        modelAndView.addObject("companyList", companiesRepo.findAllByUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName())));
        modelAndView.addObject("departmentList", departmentsService.findAllByUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName())));
        modelAndView.setViewName("contacts/create");
        return modelAndView;
    }

    @RequestMapping(value = "create.do", method = RequestMethod.POST)
    public String saveOrUpdate(@Valid Contacts obj, BindingResult bindingResult, Model model) {
        System.out.println(obj);
        if (bindingResult.hasErrors()) {
            return "contacts/create";
        } else {
            obj.setUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName()));
            obj.setCreatedDate(new Date());
            repo.save(obj);
            model.addAttribute("successMessage", "Insert Success");
            return "redirect:/contact/create.do";
        }
    }

    @RequestMapping(value = "edit/{id}", method = RequestMethod.GET)
    public String updateRole(@PathVariable Long id, Model model) {
        Optional<Contacts> obj1 = repo.findById(id);
        model.addAttribute("obj", obj1);
        return "contacts/create";
    }

    @RequestMapping(value = "del/{id}", method = RequestMethod.GET)
    public String delRole(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("successMessage", "Delete Success");
        return "redirect:/contact/create";
    }

    @RequestMapping(value = "list.do", method = RequestMethod.GET)
    public ModelAndView getList() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("list", repo.findAllByUser(userService.isUserNameAlreadyExist(loggedInUser.getCurrentUserName())));
        modelAndView.setViewName("contacts/list");
        return modelAndView;
    }

}
